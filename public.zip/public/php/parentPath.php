<?php
	DEFINE("PARENT_PATH", "/we/trammai");
?>