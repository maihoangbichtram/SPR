<meta charset="utf-8">
<style>
	span#logoSpan {
		display: block;
		text-align: right;
	}
</style>

<?php require_once("parentPath.php");?>
<span id="logoSpan"><img src="<?php echo PARENT_PATH; ?>/spr/public/logo.png"></span>