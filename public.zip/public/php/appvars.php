<?php
	$pinAccess = "1234";
?>