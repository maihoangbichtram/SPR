<?php

	session_start();
	
	$_SESSION['typed_pin'] = $_POST['typed_pin'];

?>