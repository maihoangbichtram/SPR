/*var config = {
	apiKey: "AIzaSyDou-PNqbd-hRQ8gzE1Tzht1XTUdUemVLU",
	authDomain: "red-cross-log-app.firebaseapp.com",
	databaseURL: "https://red-cross-log-app.firebaseio.com",
	projectId: "red-cross-log-app",
	storageBucket: "red-cross-log-app.appspot.com",
	messagingSenderId: "87270655424"
};
firebase.initializeApp(config);*/


  // Initialize Firebase
  /*var config = {
    apiKey: "AIzaSyDou-PNqbd-hRQ8gzE1Tzht1XTUdUemVLU",
    authDomain: "red-cross-log-app.firebaseapp.com",
    databaseURL: "https://red-cross-log-app.firebaseio.com",
    projectId: "red-cross-log-app",
    storageBucket: "red-cross-log-app.appspot.com",
    messagingSenderId: "87270655424"
  };
  firebase.initializeApp(config);*/



  var config = {
    apiKey: "AIzaSyAnIa5s8gDpTbNh5jhy_202dJ2USfJXZDc",
    authDomain: "red-cross-62c12.firebaseapp.com",
    databaseURL: "https://red-cross-62c12.firebaseio.com",
    projectId: "red-cross-62c12",
    storageBucket: "red-cross-62c12.appspot.com",
    messagingSenderId: "300125109090"
  };
  firebase.initializeApp(config);
  
  
  // Initialize Firebase
  /*var config = {
    apiKey: "AIzaSyD3moGMZw5qAy6HoVNvsAY9Qa7MX4rIJmE",
    authDomain: "red-cross-1.firebaseapp.com",
    databaseURL: "https://red-cross-1.firebaseio.com",
    projectId: "red-cross-1",
    storageBucket: "red-cross-1.appspot.com",
    messagingSenderId: "796607950142"
  };
  firebase.initializeApp(config);*/
  
  /*var config = {
    apiKey: "AIzaSyD43p2OBh2y3KKdFob-t6_RIvepnz4bVGY",
    authDomain: "red-cr.firebaseapp.com",
    databaseURL: "https://red-cr.firebaseio.com",
    projectId: "red-cr",
    storageBucket: "red-cr.appspot.com",
    messagingSenderId: "527297349518"
  };
  firebase.initializeApp(config);*/

