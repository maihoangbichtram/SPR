function getDateStamp() {
	var now = new Date();
	var date = [ now.getFullYear(), now.getMonth() + 1, now.getDate()];

	for ( var i = 1; i < 3; i++ ) {
		if ( date[i] < 10 ) {
			date[i] = "0" + date[i];
		}
	}
	
	var time = [ now.getHours(), now.getMinutes()];
	for ( var i = 0; i < 2; i++ ) {
		if ( time[i] < 10 ) {
		  time[i] = "0" + time[i];
		}
	}

	var second = now.getMilliseconds();
	var dateStamp = "" + date.join("") + time.join("") + second;
	return dateStamp;
}